var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/features/sync-selected-global-shadow.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/features/sync-selected-global-shadow.js":
/*!*****************************************************!*\
  !*** ./src/features/sync-selected-global-shadow.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

var doc = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();
var Selection = doc.selectedLayers.layers;
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var SelectionResult = 0;
  var GlobalShadowResult = 0;
  var AutoStyleLayerResult = 0;
  var SyncResult = 0; //主要功能开始

  Selection.forEach(function (item) {
    var GlobalShadow = null; //获取 Global 值

    if (item.type === "SymbolMaster") {
      SelectionResult = 1; //判断所选 Artboard 内是否有图层

      if (item.layers.length > 0) {
        //判断所选 Artboard 内图层为正确的 SymbolInstance 时
        if (item.layers[0].type === "SymbolInstance") {
          if (typeof item.layers[0].master.layers[0] !== "undefined") {
            GlobalShadow = item.layers[0].master.layers[0].style.shadows;
            GlobalShadowResult = 1;
          }
        } //判断所选 Artboard 内图层为正确的 Shape 时
        else if (item.layers[0].type === "ShapePath") {
            GlobalShadow = item.layers[0].style.shadows;
            GlobalShadowResult = 1;
          }
      }
    }

    if (SelectionResult === 1) {
      //对包含选中 symbol 的每一个 symbol 的相关图层进行设置
      var AllInstances = item.getAllInstances();
      AllInstances.forEach(function (item2) {
        //锁定并隐藏 Global symbol instance 图层
        item2.style.opacity = 0;
        item2.frame.width = 1;
        item2.frame.height = 1;
        item2.frame.x = 0;
        item2.frame.y = 0; //(设置 hidden 可能会被remove all hidden layers 操作误删)item2.hidden = true

        item2.locked = true;
        var ThisParent = item2.parent;
        var AutoStyleLayer;

        if (ThisParent.layers.find(function (item3) {
          return item3.name.indexOf("AutoStyle") !== -1;
        })) {
          AutoStyleLayer = ThisParent.layers.find(function (item4) {
            return item4.name.indexOf("AutoStyle") !== -1;
          });

          if (GlobalShadowResult === 1) {
            AutoStyleLayer.style.shadows = GlobalShadow;
            SyncResult = 1;
          }

          AutoStyleLayerResult = 1;
        }
      });
    }
  }); //判断 sync 结果并提示

  if (SelectionResult === 0) {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("请选中需要同步属性的 Global Artboard");
  } else if (GlobalShadowResult === 0) {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("未在 Global Artboard 内找到记录属性的形状图层");
  } else if (AutoStyleLayerResult === 0) {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("未找到需要同步的 AutoStyle 图层");
  } else if (SyncResult === 0) {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("同步 AutoStyle 图层属性时失败");
  } else {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Succeed In Syncing~");
  }
});

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=features_sync-selected-global-shadow.js.map