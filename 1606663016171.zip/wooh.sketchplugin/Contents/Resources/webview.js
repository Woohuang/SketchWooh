import * as xs from '../src/modules/xscapeFunctions'

xs.getFromPlugin()